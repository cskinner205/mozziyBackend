const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const { MongoClient, ObjectId } = require('mongodb');
require('dotenv').config()
const jwt=require('jsonwebtoken');
const bcrypt=require('bcrypt');
const salt=10;
const url = process.env.MONGODB_URL
const client = new MongoClient(url);
const multer = require('multer');
const PORT = process.env.PORT
// const storage = multer.memoryStorage(); // Store the image in memory

const stripe = require('stripe')('sk_test_51Ns11jSAk5KTb2JgV9x8I7Jf5KFxw2AQ1zv10TWYZ16InFaB2hEJrXzxuiX6ekk1YMkjZNnrr6nDq6CE6HZhYmLe00E9jkM9Pv');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Set the destination where the uploaded files will be stored
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    // Set the filename for the uploaded file
    cb(null, Date.now() + '-' + file.originalname);
  },
});
const upload = multer({ storage:storage });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));



app.post('/api/create-payment-intent', async (req, res) => {
  const { amount, currency } = req.body;
   console.log('i m in backend') 
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount,
      currency,
    });
    res.status(200).json({ clientSecret: paymentIntent.client_secret });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});






app.post('/api/upload', upload.single('file'), async(req, res) => {
  console.log("")

  let data ={
    userForeignKey: new ObjectId(req.body.userId),
    fileData: req.file,
    country : req.body.country ,
    category: req.body.category,
    photoTitle: req.body.photoTitle,
    photoDescription: req.body.photoDescription,
    price: Number(req.body.price),
    isFavorite:false,
    createdAt: new Date().toISOString(),
  }
  if (!req.file) {
    return res.status(400).json({ message: 'No file provided' });
  } 
  else{
        await client.connect();
        // Select a database
        const db = client.db('mozziy_new');
        // Select a collection
        const collection = db.collection('Event');

        const result = await collection.insertOne(data);
        if(result.acknowledged)
        res.status(200).json({ message: 'File uploaded successfully' });
      }
})

app.use('/uploads', express.static('uploads'));

app.get("/api/test",(req,res)=>{
console.log("GET API IS HIT test")
res.send("HAI GET API HIT test")
})

app.post("/register",async(req,res)=>{
  console.log("register api is hit")
  let msg
    try {
        // Connect to the MongoDB server
        await client.connect();
    
        // Select a database
        const db = client.db('mozziy_new');
    
        // Select a collection
        const collection = db.collection('User');

        const user = await collection.findOne({  email: req.body.email });
        if (user) {
          return res.status(400).send({
            message: "Failed! Email is already in use!"
          });
        }
        else{
       let encryptedPassword = bcrypt.hashSync(req.body.password, salt);
        
        let data = {
          name: req.body.name,
          email: req.body.email,
          password: encryptedPassword,
          createdAt: new Date().toISOString(),
          signedByGoogle:false
        }

        // Insert the data into the collection

        const result = await collection.insertOne(data);

        // Print the inserted document ID
        console.log('Inserted document ID:', result.insertedId);

        if(result.insertedId ){
          msg="success";
        }
      }
      } catch (error) {
        console.error('Error:', error);
        if(error){
          msg={
            msg:error,
            status:500,
            success:false
          };
        }
      } finally {
        // Close the MongoDB client
        client.close();
      }

    console.log("RESISTER API IS HIT ")
    res.send({msg})
})

  app.post('/loginWithGoogle', async(req, res)=>{
    try{

      console.log("login with google api is hit")
      await client.connect();
    
      // Select a database
      const db = client.db('mozziy_new');
  
      // Select a collection
      const collection = db.collection('User');
      console.log(req.body)
      let {email, name, photo } = req.body
           
      const user = await collection.findOne({ email: email});
      console.log(user,"user")
      if(user){
      if(user.signedByGoogle){
        res.status(200).send({msg:"Authorized User! Redirect to login page", signedByGoogle:true, id:user._id});
      }
      else if(user.signedByGoogle===false){
        res.status(409).send({msg:"Email already exists!. Please sign in by email and password", signedByGoogle:false})
      }
     } else{
        data={
          email,
          name,
          image:photo,
          emailVerified:null,
          createdAt: new Date().toISOString(),
          signedByGoogle:true
        }
      

      const result = await collection.insertOne(data);

      // Print the inserted document ID
      console.log('Inserted document ID:', result.insertedId);

      if(result.insertedId){
        res.send({message:"User Created Successfully", id:result.insertedId, signedByGoogle:true, status:200})
      }
    }
    }
    catch (error) {
      console.error('Errors:', error);   
      res.send({
        message: error.msg,
        signedByGoogle:true, 
        status: 500
      })
    } finally {
      // Close the MongoDB client
     
      client.close();
    }
   
  })

app.post('/api/login',async(req, resp)=>{
  try{
    console.log("login api is run")
        await client.connect();
        // Select a database
        const db = client.db('mozziy_new');
        // Select a collection
        const collection = db.collection('User');

        const result = await collection.findOne({email: { $regex: new RegExp(req.body.email, 'i') }} )

      if(result){
        if(result.signedByGoogle){
          
            resp.send({success: false,
            message: "Please Login with google Id"
          })
          console.log("asdlkasioduh22222")
        }
        else{
          bcrypt.compare(req.body.password, result.password,(err, res)=>{
     if(err){
      console.log(err)
      console.log("asdlkasioduh222244444444444")
     }
          if (res) {
            // Send JWT
            console.log("asdl66666666666")
            const payload = {
              userId: result._id,
              username: result.name
            };
  
            const secretKey = process.env.JWT_SECRET_KEY;
  
            const token = jwt.sign(payload, secretKey);
            resp.send( {
              id:result._id,
              token: token,
              msg:"Authentic User",
              signedByGoogle:false
            })
           
          } else {
            // response is OutgoingMessage object that server response http request
           
            console.log("we are in else")
            resp.send({
              success: false,
              message: "Invalid Username or password"
            })
          }
          });
        }
        }else{
          resp.send({
            success:false,
            message:"No email exists"
          })
        }
  }catch (error) {
    console.error('Error:', error);
    if(error){
      console.error(error)
      resp.send({
        msg:error,
        status:500
      })
  }}
})

// this is the api which will fetch the events in the dashboard page  
app.post("/api/getEvents", async(req, res)=>{
  try{
    console.log("req.body",req.body)
    // console.log("get events api is run");
    await client.connect();
    // Select a database
    const db =  client.db('mozziy_new');
    // Select a collection
    const collection = db.collection('Event');

    const result = await collection.find({userForeignKey: new ObjectId(req.body.userId)}).toArray();
    if(result){
      res.json(result)
    }

  }
  catch(err){
    console.log(err)
    res.send({message:err, status:400})
  }
})

app.post("/api/getAllFavoriteEvents", async(req, res)=>{
  try{
    console.log("req.body",req.body)
    // console.log("get events api is run");
    await client.connect();
    // Select a database
    const db =  client.db('mozziy_new');
    // Select a collection
    const collection = db.collection('Event');

    const result = await collection.find({userForeignKey: new ObjectId(req.body.userId), isFavorite:true }).toArray();
    if(result){
      res.json(result)
    }

  }
  catch(err){
    console.log(err)
    res.send({message:err, status:400})
  }
})


app.post('/addEventToFavorite', async(req, res)=>{
  try{
    console.log("add event to favorite api is run")
    console.log("req.body",req.body)

    const {id, heart} = req.body
    await client.connect();
    // Select a database
    const db =  client.db('mozziy_new');
    // Select a collection
    const collection = db.collection('Event');
    const filter = {_id: new ObjectId(id)}
    const update = {$set:{isFavorite:heart}}
    const options = { returnNewDocument: true }
    const result = await collection.findOneAndUpdate(filter,update, options)
    console.log("result",result)

    if(result){
      res.send({msg:"Document updated successfully", status:200})
    }
      client.close()
    
  }
catch(err){
  console.log(err)
  res.send({message:err, status:400})
}
})
app.listen(PORT,()=>{
    console.log("SERVER RUNNING ON PORT 5000")
})